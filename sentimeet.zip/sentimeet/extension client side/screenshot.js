function setScreenshotUrl(og_url) {
	fetch(og_url).then( res => res.blob()).then(result =>
	{
	var fileName = "happyface.jpg"
	var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";

    var url = window.URL.createObjectURL(result);
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
    var xhr = new XMLHttpRequest();
	xhr.open("GET", url);
	xhr.responseType = "blob";

	xhr.onload = function () {
    saveData(this.response, fileName); // saveAs is now your function
	};
	xhr.send();
	fetch("http://dea09bec5e9c.ngrok.io/getSentimentAnalysis/happyface.jpg").then(r => r.text()).then(result => {
		var json_obj = JSON.parse(result)
		console.log("JSON OBJ" + json_obj)
		document.getElementById('angry').innerHTML= json_obj.ANGRY;
		document.getElementById('calm').innerHTML = json_obj.CALM;
		document.getElementById('disgust').innerHTML = json_obj.DISGUSTED;
		document.getElementById('confused').innerHTML = json_obj.CONFUSED;
		document.getElementById('fear').innerHTML = json_obj.FEAR;
		document.getElementById('sad').innerHTML = json_obj.SAD;
		document.getElementById('happy').innerHTML = json_obj.HAPPY;
		document.getElementById('surprised').innerHTML = json_obj.SURPRISED;
		document.getElementById('unknown').innerHTML = json_obj.UNKNOWN;

	})
	})

  
}
