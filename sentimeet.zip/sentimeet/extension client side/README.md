This Repo contains code of Screenshot taking chrome extension article written by me on Medium. It takes simple screenshot of the tab currently opened in chrome.
To read about the code you can follow the article link at medium.
https://medium.com/iamdeepinder/creating-a-screenshot-taking-chrome-extension-from-scratch-cdb0e33a0013

Camera icon taken from https://www.flaticon.com
