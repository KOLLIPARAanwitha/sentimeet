import boto3
import os
from PIL import Image
from flask import Flask, render_template, jsonify
import requests


app = Flask(__name__)


def getDictionary(file):
    dict_emot = {0:'HAPPY', 1:'ANGRY', 2:'SAD', 3:'SURPRISED', 4:'DISGUSTED', 5:'CONFUSED', 6:'FEAR', 7:'CALM', 8:'UNKNOWN'}
    client = boto3.client('rekognition', region_name='us-west-2', aws_access_key_id='SECURITY ID (not displayed for privacy concerns)', aws_secret_access_key='ACCESS ID (not displayed for privacy concerns)')
    frequency_list = getFrequency(file, client)
    dict_to_output = {}
    sum_emot = sum(frequency_list)
    for x in range(0, len(frequency_list)):
        dict_to_output[dict_emot[x]] = str(((frequency_list[x]/sum_emot)*100))+"%"
    return dict_to_output

def getFrequency(img, client):
    emotions = ['HAPPY', 'ANGRY', 'SAD', 'SURPRISED', 'DISGUSTED', 'CONFUSED', 'FEAR', 'CALM','UNKNOWN']
    frequency = [0,0,0,0,0,0,0,0,0] 
    hi = os.path.expanduser("~/Downloads/" + img)
    with open(hi, "rb") as image:
        f = image.read()

    response = client.detect_faces(
        Image={
            'Bytes': f

        },
        Attributes=[
            'ALL',
        ]

    )
    os.remove(hi)
    for face in response['FaceDetails']:
        maxe = ''
        maxc = 0
        for emote in face['Emotions']:
            if emote['Confidence'] > maxc:
                maxe = emote['Type']
                maxc = emote['Confidence']
        frequency[emotions.index(maxe)]+=1
    return frequency

@app.route('/getSentimentAnalysis/<photo_url>', methods = ['GET'] )
def sentiment_analysis(photo_url):
    print("URL", photo_url)
    return jsonify(getDictionary(photo_url))

@app.route('/')
def hello_world():
    return "Hello WOrld"    

if __name__ == '__main__': 
    app.run(debug=True)

    #main()
# import boto3
# import json

# def detect_faces(photo, bucket):

#     client=boto3.client('rekognition')

#     response = client.detect_faces(Image={'S3Object':{'Bucket':bucket,'Name':photo}},Attributes=['ALL'])

#     print('Detected faces for ' + photo)    
#     for faceDetail in response['FaceDetails']:
#         print('The detected face is between ' + str(faceDetail['AgeRange']['Low']) 
#               + ' and ' + str(faceDetail['AgeRange']['High']) + ' years old')
#         print('Here are the other attributes:')
#         print(json.dumps(faceDetail, indent=4, sort_keys=True))
#     return len(response['FaceDetails'])
# def main():
#     photo='photo'
#     bucket='bucket'
#     face_count=detect_faces(photo, bucket)
#     print("Faces detected: " + str(face_count))


# if __name__ == "__main__":
#     main()